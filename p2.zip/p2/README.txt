Development Environment Usage:
===============================================
Windows: 
Open the provided Visual Studio Solution (.sln) file in the visual_studio_project directory

Linux/Mac Eclipse:
Import the project into your workspace as a C/C++ Makefile project as you did for Lab 0

File => Import => C/C++ => Existing Code as Makefile Project


Command-Line Compilation:
===============================================
Linux/Mac: From the command line, type:

> make -f Makefile.linux

or

> make -f Makefile.mac

to build the framework and:

> ./P2

to run the demo.


