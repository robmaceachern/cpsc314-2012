Robert MacEachern
m9c7
42415091

By submitting this ﬁle, I hereby declare that I worked individually on this assignment and that I am the
only author of this code. I have listed all external resoures (web pages, books) used below. I have listed all
people with whom I have had signiﬁcant discussions about the project below.

I implemented the three viewing/flying modes and each of the controls for the views.